import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyDPR1-QoukeBEBM6Bw0_4F-ZP_ZOi8Q2Sg",
    authDomain: "collabsphere-2ff89.firebaseapp.com",
    projectId: "collabsphere-2ff89",
    storageBucket: "collabsphere-2ff89.appspot.com",
    messagingSenderId: "1052302666732",
    appId: "1:1052302666732:web:54e99b23963a3cad45aec9",
    measurementId: "G-SMWFGRDYDY"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Handle login form submission
document.getElementById('loginForm').addEventListener('submit', async (event) => {
    event.preventDefault(); // Prevent default form submission behavior

    const email = document.querySelector('input[type="email"]').value;
    const password = document.querySelector('input[type="password"]').value;

    try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        alert('Login successful!');
        // Redirect to third.html or dashboard page
        window.location.href = "index.html";
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
});